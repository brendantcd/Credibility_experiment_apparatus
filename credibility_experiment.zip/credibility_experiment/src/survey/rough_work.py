class SurveyWizardThree(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardOThreene, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        PATH_THREE_IMAGES = self.request.session.get('path_three_images', ['P1D1.jpg', 'P2D2.jpg', 'P3D3.jpg', 'P4D4.jpg', 'P5D5.jpg', 'P6D6.jpg', 'P7D7.jpg', 'P8D8.jpg', 'P9D9.jpg'])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        
        if step in range (5, 19):   
            self.request.session['path_three_images'] = PATH_THREE_IMAGES                              
            self.request.session['images'] = images
            self.request.session['slider_DV_values'] = slider_DV_values
                                                                           
            if step == 5:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 5: %s', PATH_THREE_IMAGES)
                first_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(first_image)               
                context['display_image'] = first_image                                 
                images.insert(0, first_image)   
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                          
                
                logger.debug('\n\nThis is your first image %s', images[0])
                logger.debug('\nThis is your images list in 5: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 5 %s', slider_DV_values)
                                                       
            elif step == 6:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 6: %s', PATH_THREE_IMAGES)
                second_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(second_image)
                context['display_image'] = second_image                                 
                images.insert(1, second_image)   
                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')    
                
                logger.debug('\n\nThis is your second image %s', images[1])
                logger.debug('\nThis is your images list in 6: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 6 %s', slider_DV_values)
                                                
            elif step == 7:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 7: %s', PATH_THREE_IMAGES)
                third_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(third_image)
                context['display_image'] = third_image                                 
                images.insert(2, third_image)                  
                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')    
                
                logger.debug('\n\nThis is your third image %s', images[2])
                logger.debug('\nThis is your images list in 7: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 7 %s', slider_DV_values)
                                                                               
            elif step == 8:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 8: %s', PATH_THREE_IMAGES)
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 8: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 8 %s', slider_DV_values)
    
                context['first_image'] = self.request.session['first_image']
                context['second_image'] = self.request.session['second_image']
                context['third_image'] = self.request.session['third_image']                 
                context['first_slider'] = slider_DV_values[0]  
                context['second_slider'] = slider_DV_values[1]       
                context['third_slider'] = slider_DV_values[2]                               
                         
            elif step == 9:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 9: %s', PATH_THREE_IMAGES)
                fourth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(fourth_image)               
                context['display_image'] = fourth_image                                 
                images.insert(3, fourth_image)   
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                          
                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 9: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 9 %s', slider_DV_values)
                                                                                           
            elif step == 10:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 10: %s', PATH_THREE_IMAGES)
                fifth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(fifth_image)
                context['display_image'] = fifth_image                                 
                images.insert(4, fifth_image)   
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    

                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 10: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values)
                                                                        
            elif step == 11:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 11: %s', PATH_THREE_IMAGES)
                sixth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(sixth_image)
                context['display_image'] = sixth_image                                 
                images.insert(5, sixth_image)                  
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')    
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 7: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                      
            elif step == 12:                 
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 12: %s', PATH_THREE_IMAGES)
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 12: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)

                context['fourth_image'] = self.request.session['fourth_image']
                context['fifth_image'] = self.request.session['fifth_image']
                context['sixth_image'] = self.request.session['sixth_image']                 
                context['first_slider'] = slider_DV_values[3]  
                context['second_slider'] = slider_DV_values[4]       
                context['third_slider'] = slider_DV_values[5]    
                                                                           
            if step == 13:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 13: %s', PATH_THREE_IMAGES)
                seventh_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(seventh_image)               
                context['display_image'] = seventh_image                                 
                images.insert(6, seventh_image)   
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')                          
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 5: %s', images)

                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
                                                       
            elif step == 14:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 14: %s', PATH_THREE_IMAGES)
                eight_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(eight_image)
                context['display_image'] = eight_image                                 
                images.insert(7, eight_image)   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image')    
                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 6: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                
            elif step == 15:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 15: %s', PATH_THREE_IMAGES)
                ninth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(ninth_image)
                context['display_image'] = ninth_image                                 
                images.insert(8, ninth_image)                  
                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')    
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 7: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                       
            elif step == 16:                 
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 16: %s', PATH_THREE_IMAGES)
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 16: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                      
                context['seventh_image'] = self.request.session['seventh_image']
                context['eight_image'] = self.request.session['eight_image']
                context['ninth_image'] = self.request.session['ninth_image']                 
                context['first_slider'] = slider_DV_values[6]  
                context['second_slider'] = slider_DV_values[7]       
                context['third_slider'] = slider_DV_values[8] 
   
            elif step == 17:
                logger.debug('\n\nThis is the available list of PATH_THREE_Images in 17: %s', PATH_THREE_IMAGES)
                logger.debug('\nThis is your images list in 17: %s', images)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context['first_image'] = images[0]
                context['second_image'] = images[1]
                context['third_image'] = images[2]   
                context['fourth_image'] = images[3]
                context['fifth_image'] = images[4]
                context['sixth_image'] = images[5]   
                context['seventh_image'] = images[6]
                context['eight_image'] = images[7]
                context['ninth_image'] = images[8] 
                                                                                       
            steps = ['5','6','7','9','10','11','13','14','15']              
            dv_steps = ['8','12','16',]         
                                                                                                             
            context.update({'steps' : steps, 'dv_steps' : dv_steps})
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        global SurveyWizardThreeCounter
        global TotalMaxCounter 
        SurveyWizardThreeCounter += 1   
        TotalMaxCounter += 1
        return render(self.request, 'Return_to_AMT.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })  



