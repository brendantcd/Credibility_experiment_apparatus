# -*- coding: utf-8 -*-

from django import forms 
from django.forms import ModelForm
from django.db import models
import datetime
from django.core.exceptions import ValidationError
from multiselectfield import MultiSelectField





class URL(models.Model):
    location = models.CharField(max_length=25)




class SurveyCounter(models.Model):

    SURVEY_WIZARD_TYPE_CHOICES = (
                              ('SURVEY_WIZARD_ONE', 'survey_wizard_one'),
                              ('SURVEY_WIZARD_TWO', 'survey_wizard_two'), 
                              ('SURVEY_WIZARD_THREE', 'survey_wizard_three'), 
                              ('SURVEY_WIZARD_FOUR', 'survey_wizard_four'), 
                              ('SURVEY_WIZARD_FIVE', 'survey_wizard_five'),
                              ('SURVEY_WIZARD_SIX', 'survey_wizard_six'), 
                              ('SURVEY_WIZARD_SEVEN', 'survey_wizard_seven'),
                              ('SURVEY_WIZARD_EIGHT', 'survey_wizard_eight'),
                              ('SURVEY_WIZARD_NINE', 'survey_wizard_nine'),
                              )

    survey_wizard_type = models.CharField(max_length=1000, choices=SURVEY_WIZARD_TYPE_CHOICES)
    survey_wizard_count = models.SmallIntegerField(default=0)

    def __unicode__(self):
        return self



class TotalCounter(models.Model):

    total_max_counter = models.SmallIntegerField(default=0) 

    def __unicode__(self):
        return self  
      
    
    


class Person(models.Model):
    

    
    # These take the value of a jQuery Slider Bar
    instruction_task_one_image = models.CharField(null=True, max_length=100, blank=True) 
    instruction_task_one_value = models.SmallIntegerField(null=True, blank=True, max_length=1000)

    instruction_task_two_image = models.CharField(null=True, max_length=100, blank=True)     
    instruction_task_two_value = models.SmallIntegerField(null=True, blank=True, max_length=1000)
    
    # The below  four pages are the like section dividers between the different stages of the survey
    # They do not have question on the pages, just messages to the users
    start = models.CharField(null=True, max_length=100, blank=True)  
    rate = models.CharField(null=True, max_length=100, blank=True)  
    reflect = models.CharField(null=True, max_length=100, blank=True)  
    submit = models.CharField(null=True, max_length=100, blank=True)  


    spike_one_image = models.CharField(null=True, max_length=100, blank=True)     
    spike_one_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    
    slider_one_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_one_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    slider_two_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_two_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    slider_three_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_three_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    
    DV_one_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_two_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_three_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 

    slider_four_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_four_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    slider_five_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_five_value = models.SmallIntegerField(null=True, max_length=100, blank=True)
    slider_six_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_six_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 

    DV_four_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_five_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_six_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 

    spike_two_image = models.CharField(null=True, max_length=100, blank=True)     
    spike_two_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 

    slider_seven_image = models.CharField(null=True, max_length=100, blank=True)         
    slider_seven_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    slider_eight_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_eight_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    slider_nine_image = models.CharField(null=True, max_length=100, blank=True)     
    slider_nine_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    
    DV_seven_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_eight_value = models.SmallIntegerField(null=True, max_length=100, blank=True) 
    DV_nine_value = models.SmallIntegerField(null=True, max_length=100, blank=True)     
        
    DV_positive = models.CharField(null=True, max_length=100, blank=True) 
    DV_negative = models.CharField(null=True, max_length=100, blank=True) 
    
    
    
    
    
    
    
    prolific_academic_ID = models.CharField(max_length=100, verbose_name='Please enter your Prolific Academic ID. This is necessary to receive Payment on acceptance of the submission.')     
    
    
    
    
    # TODO - Store which path the user is on in the database
    # This would be a serious help as it is quite time consuming to work out
    
    
    
    
    

    
   # sender = models.EmailField(null=True, blank=True, verbose_name='What is your email address?')     
    
    birthdate = models.DateField(null=True, blank=True) #overwritten in forms.py so passed no more arguments
    
    SEX = (
        ('0', 'Male'),
        ('1', 'Female'),
        ('2', 'Other'),
        ('3', 'I prefer not to say'))    
    sex = models.CharField(null=True, blank=True, max_length=100, choices=SEX, verbose_name='What gender are you?')

                       
    MARITAL_STATUS = (
        ('0', "Single"),
        ('1', "In a relationship"),
        ('2', "Married"),
        ('3', "Divorced"),
        ('4', "Separated"),
        ('5', "Widowed"),)    
    marital_status = models.CharField(null=True, blank=True, max_length=100, choices=MARITAL_STATUS, verbose_name='What is your relationship status?')             

                   
    STATE = (
        ('0', 'Alabama'),
        ('1', 'Alaska'),
        ('2', 'Arizona'),
        ('3', 'Arkansas'),
        ('4', 'California'),
        ('5', 'Colorado'),
        ('6', 'Connecticut'),
        ('7', 'Delaware'),
        ('8', 'Florida'),
        ('9', 'Georgia'),
        ('10', 'Hawaii'),
        ('11', 'Idaho'),
        ('12', 'Illinois'),
        ('13', 'Indiana'),
        ('14', 'Iowa'),
        ('15', 'Kansas'),
        ('16', 'Kentucky'),
        ('17', 'Louisiana'),
        ('18', 'Maine'),
        ('19', 'Maryland'),
        ('20', 'Massachusetts'),
        ('21', 'Michigan'),
        ('22', 'Minnesota'),
        ('23', 'Mississippi'),
        ('24', 'Missouri'),
        ('25', 'Montana'),
        ('26', 'Nebraska'),
        ('27', 'Nevada'),
        ('28', 'New Hampshire'),
        ('29', 'New Jersey'),
        ('30', 'New Mexico'),
        ('31', 'New York'),
        ('32', 'North Carolina'),
        ('33', 'North Dakota'),
        ('34', 'Ohio'),
        ('35', 'Oklahoma'),
        ('36', 'Oregon'),
        ('37', 'Pennsylvania'),
        ('38', 'Rhode Island'),
        ('39', 'South Carolina'),
        ('40', 'South Dakota'),
        ('41', 'Tennessee'),
        ('42', 'Texas'),
        ('43', 'Utah'),
        ('44', 'Vermont'),
        ('45', 'Virginia'),
        ('46', 'Washington'),
        ('47', 'West Virginia'),
        ('48', 'Wisconsin'),
        ('49', 'Wyoming'),
        ('50', 'District of Columbia'),
        ('51', 'Puerto Rico'),
        ('52', 'Guam'),
        ('53', 'American Samoa'),
        ('54', 'US Virgin Islands'),
        ('55', 'Northern Mariana Islands'),)           
    state = models.CharField(null=True, blank=True, max_length=100, choices=STATE, verbose_name='What State are you from?')
      
              
    INTERNET_USAGE = (
        ('0', 'Less than one hour a day'),
        ('1', '1 - 2 hours a day'),
        ('2', '2 - 4 hours a day'),
        ('3', '4 - 6 hours a Day'),
        ('4', '6 - 8 hours a day'),
        ('5', '8 + hours a day'), )
    internet_usage = models.CharField(null=True, blank=True, max_length=100, default=None, choices=INTERNET_USAGE, verbose_name='How long do you spend on the Internet each day?')

                
    SMART_PHONE_OWNERSHIP = (
        ('0', 'Yes'),
        ('1', 'No'),)    
    smart_phone_ownership = models.CharField(null=True, blank=True, max_length=100, choices=SMART_PHONE_OWNERSHIP, verbose_name='Do you own a Smartphone?')
 
  
    SMART_PHONE_USAGE = (
        ('0', 'Less than one hour a day'),
        ('1', '1 - 2 Hours a day'),
        ('2', '2 - 4 hours a day'),
        ('3', '4 - 6 hours a Day'),
        ('4', '6 - 8 hours a day'),
        ('5', '8 + hours a day'),)    
    smart_phone_usage = models.CharField(null=True, max_length=100, blank=True, default=None, choices=SMART_PHONE_USAGE, verbose_name='If Yes, how many hours a day do you access the Internet on it?')
 

    # These start at 1 because you may need to use them to create composite Socio-Economic Scores'   
    EDUCATION = (
        ('1', 'Elementary school only'),
        ('2', 'Some high school, but did not finish'),
        ('3', 'Completed high school'),
        ('4', 'Some college, but did not finish'),
        ('5', 'Two-year college degree / A.A / A.S.'),
        ('6', 'Four-year college degree / B.A. / B.S.'),
        ('7', 'Some graduate study'),
        ('8', 'Completed Masters or professional degree'),
        ('9', 'Advanced Graduate study or Ph.D.'),
        ('10', 'Other'), )
    education = models.CharField(null=True, blank=True, max_length=100, default=None, choices=EDUCATION, verbose_name='What is the highest level of education you have completed?')

    # These start at 1 because you may need to use them to create composite Socio-Economic Scores'   
    WAGES = (   
        ('1', 'Under $10,000'),
        ('2', '$10,000 - $19,999'),
        ('3', '$20,000 - $29,999'),
        ('4', '$30,000 - $39,999'),
        ('5', '$40,000 - $49,999'),
        ('6', '$50,000 - $59,999'),
        ('7', '$60,000 - $69,999'),
        ('8', '$70,000 - $79,999'),
        ('9', '$80,000 - $89,999'),
        ('10', '$90,000 - $99,999'),      
        ('11', '$100,000 - $109,999'),
        ('12', '$110,000 - $119,999'),
        ('13', '$120,000 - $129,999'),
        ('14', '$130,000 - $139,999'),
        ('15', '$140,000 - $149,999'),
        ('16', '$150,000 - $159,999'),
        ('17', '$160,000 - $169,999'),
        ('18', '$170,000 - $179,999'),
        ('19', '$180,000 - $189,999'),
        ('20', '$190,000 - $199,999'),
        ('21', '$200,000 - $209,999'),
        ('22', '$210,000 - $219,999'),
        ('23', '$220,000 - $229,999'),
        ('24', '$230,000 - $239,999'),
        ('25', '$240,000 - $249,999'),
        ('26', 'Over $250,000'),)
    wages = models.CharField(null=True, blank=True, max_length=100, default=None, choices=WAGES, verbose_name='What is your expected income range for 2017?')
       
    # These start at 1 because you may need to use them to create composite Socio-Economic Scores'     
    PRESENTAGE_SAVINGS = ( 
        ('1', '0%'),
        ('2', '0% - 5%'),
        ('3', '5% - 10%'),
        ('4', '10% - 15%'),
        ('5', '15% - 20%'),
        ('6', '20% - 25%'),
        ('7', '25% - 30%'),
        ('8', '30% - 35%'),
        ('9', '35% - 40%'),
        ('10', '40% - 45%'),
        ('11', '45% - 50%'),
        ('12', '50%+'),)
    presentage_savings = models.CharField(null=True, blank=True, max_length=100, default=None, choices=PRESENTAGE_SAVINGS, verbose_name='What proportion of your weekly/monthly income do you save?')
       
    # These start at 1 because you may need to use them to create composite Socio-Economic Scores'          
    OCCUPATION = (   
        ('1', 'Stay at home Parent'),
        ('2', 'Student'),
        ('3', 'Unemployed'),
        ('4', 'Professional'),
        ('5', 'Semi-professional'),
        ('6', 'Skilled professional'),
        ('7', 'Skilled manual'),
        ('8', 'Semi-skilled manual'),
        ('9', ' Unskilled manual'),
        ('10', 'Other') )
    occupation = models.CharField(null=True, blank=True, max_length=100, default=None, choices=OCCUPATION, verbose_name='Which best describes your current occupation?')
       
           
    #===========================================================================
    # LIVING = (
    #     ('RENT_ALONE', 'Rent alone'),
    #     ('RENT_MULTIPLE_OCCUPANCY', 'Rent in multiple occupancy'),
    #     ('DORMITORY', 'Dormitory'),
    #     ('OWN_HOME_WITH_MORTGUAGE', 'Own home, with mortgage'),
    #     ('OWEN_HOME_NO_MORTGUAGE', 'Own home, no mortgage'),
    #     ('LIVING_WITH_FAMILY', 'Living with family'),
    #     ('NO_PERMANENT_LIVING_ADDRESS', 'No permanent living address'),
    #     ('OTHER', 'Other'),)
    # living = models.CharField(null=True, blank=True, max_length=100, default=None, choices = LIVING, verbose_name = 'What are your current living arrangements?')
    #===========================================================================

   
    
    POLITICAL_LEANING = (
        ('0', 'Strong Liberal'),
        ('1', 'Not so strong Liberal'),
        ('2', 'Independent leaning Liberal'),
        ('3', 'Independent'),
        ('4', 'Independent leaning Conservative'),
        ('5', 'Not so strong Conservative'),
        ('6', 'Strong Conservative'),
        ('7', 'Other'),
        ('8', "Don't know"), )
    political_leaning = models.CharField(null=True, blank=True, max_length=100, default=None, choices = POLITICAL_LEANING, verbose_name = 'What most closely describes your political viewpoint?')
         
           
    DEMOCRAT_REPUBLICAN = (
        ('0', 'Strong Democrat'),
        ('1', 'Not so strong Democrat'),
        ('2', 'Independent leaning Democrat'),
        ('3', 'Independent'),
        ('4', 'Independent leaning Republican'),
        ('5', 'Not so strong Republican'),
        ('6', 'Strong Republican'),
        ('7', 'Other'),
        ('8', "Don't know"),)
    democrat_republican = models.CharField(null=True, blank=True, max_length=100, default=None, choices = DEMOCRAT_REPUBLICAN, verbose_name = 'What most clearly reflects your political leaning?')
            
    VOTING_RIGHTS = (
        ('0', 'Extremely important'),
        ('1', 'Very important'),
        ('2', 'Moderately Important'),
        ('3', 'Somewhat important'),
        ('4', 'Not very important'),
        ('5', 'Of no importance'),
        ('6', 'Other'),
        ('7', "Don't know"),)
        
    voting_rights = models.CharField(null=True, blank=True, max_length=100, default=None, choices = VOTING_RIGHTS, verbose_name = 'How important do you feel it is to exercise your voting rights?')
        
    # You need to be careful here and check what value is being stored when no value is selected
    # Because this is Multiple Choice the values will need to be divided into separate columns in the database
    # It would be great to find an automatic way of doing this as it is very time consuming and likely prone to errors
    # That is why you start at 1. Because you need to put a 0 into each column when the multiple choice option was not selected
    ELECTION_TYPE = (
        ('1', 'None'),
        ('2', 'Local elections'),
        ('3', 'State elections e.g. Governorship'),
        ('4', 'National elections e.g. Congress and Senate'),
        ('5', 'Presidential elections'),
        ('6', 'Other'),
        ('7', "Don't know"),)  
    election = MultiSelectField(null=True, blank=True, max_length=100, choices=ELECTION_TYPE, verbose_name = 'Which elections do you regularly vote in or intend to vote in? Select all that apply.')




    # You need to be careful here and check what value is being stored when no value is selected
    # Because this is Multiple Choice the values will need to be divided into separate columns in the database
    # It would be great to find an automatic way of doing this as it is very time consuming and likely prone to errors
    # That is why you start at 1. Because you need to put a 0 into each column when the multiple choice option was not selected    
    NEWS_ACCESS = (  
        ('1', 'Radio'),
        ('2', 'TV'),
        ('3', 'Newspaper'), 
        ('4', 'Internet'),
        ('5', 'Social Media'),
        ('6', 'None'),
        ('7', 'Other'),)
    news_access = MultiSelectField( blank=True, max_length=100, choices=NEWS_ACCESS, verbose_name = 'Which mediums do you access News from most often? Select all that apply.')
    
    
    NEWS_ACCESS_TIMES = (  
        ('0', 'Less than once per day'),
        ('1', '1 - 2 times per day'),
        ('2', '2 - 4 times per day'),
        ('3', '4 - 6 times per Day'),
        ('4', '6 - 8 times per day'),
        ('5', '8 - 10 times per day'),
        ('6', '10 + times a day'), )
    news_access_times = models.CharField(null=True, blank=True, max_length=100, default=None, choices=NEWS_ACCESS_TIMES, verbose_name='If the Internet is one of your primary sources of News, how many times do you check it each day?')
    
    

  
  
  
    WEBSITES = (
        ('0', 'None'),
        ('1', 'Guardian'),
        ('2', 'Telegraph'),
        ('3', 'Independent'),
        ('4', 'Economist'),
        ('5', 'The Spectator'),
        ('6', 'New Statesman'),
        ('7', 'Al Jazeera'),
        ('8', 'BBC'),
        ('9', 'Reuters'),)
    websites_recognised = MultiSelectField( blank=True, max_length=100, choices=WEBSITES, verbose_name = 'Did you recognize any of the below News websites used in this experiment? Select each that you recognized.')       
    websites_bised = MultiSelectField( blank=True, max_length=100, choices=WEBSITES, verbose_name = 'Do you consider any of these News websites used in this experiment to be especially biased? Select each that you consider biased.')       
              




    #Y_N_M_IDK = Yes_No_Maybe_I_Dont_Know
    Y_N_M_IDK = (
        ('0', 'Yes'),
        ('1', 'No'),
        ('2', 'Maybe'),
        ('3', 'I dont know' ), )
    design_impact_perception_of_bias_website = models.CharField(null=True, blank=True, max_length=100, default=None, choices=Y_N_M_IDK, verbose_name='Does a websites design impact your perception of bias in the content of its articles?')
    design_impact_perception_of_bias_organsiation = models.CharField(null=True, blank=True, max_length=100, default=None, choices=Y_N_M_IDK, verbose_name='Does a websites design impact your perception of bias in the organization behind the website?')
    links_impact_perception_of_bias_organsiation = models.CharField(null=True, blank=True, max_length=100, default=None, choices=Y_N_M_IDK, verbose_name='Do the links to other articles or other content in the same website influence your perception of Bias in the News organization?')
    links_impact_perception_of_professionalism_organsiation = models.CharField(null=True, blank=True, max_length=100, default=None, choices=Y_N_M_IDK, verbose_name='Do the links to other articles or other content in the same website influence your perception of the professionalism in the News organization?')
 

          
          
    FEATURE_ASPECT = (
        ('0', 'Low quality advertisements'),
        ('1', 'Emotive language'),
        ('2', 'Advertisements for cheap or low quality products or services'),
        ('3', 'Lack of demonstrated research'),
        ('4', 'Too many advertisements'),
        ('5', 'Bad quality writing'),
        ('6', 'Advertisements which are too prominent or gaudy'),
        ('7', 'Unsupported claims in the article'),
        ('8', 'Low quality images'),
        ('9', 'Lack of balance in the article'),
        ('10', 'No information about the author'),
        ('11', 'Lack of objectivity in the article'),
        ('12', 'No article information e.g. date stamp'),
        ('13', 'Lack of obvious history or research in the article'),
        ('14', 'Bad or broken alignment in the design'),
        ('15', 'Bad graphs or figures in the article'),
        ('16', 'Constant or oversized appeals to share content or connect via social media'),
        ('17', 'Obvious slant to support one individual position or argument'),
        ('18', 'Too much sponsored content'),
        ('19', 'Omitted facts from the article'),
        ('20', 'Discussion or comment facilities with signs of extreme views or lack of respect'),
        ('21', 'Bombastic headlines'),
        ('22', 'Bad color schemes used in the design'),
        ('23', 'Lack of direct quotations of supporting data'),
        ('24', 'Advertisements which move, make sound or otherwise intrude on the user experience'),
        ('25', 'Use of words which have been deliberately chosen to give positive or negative impressions'),
        ('26', 'No links to other articles on the same topic or an obvious experience writing on the subject matter'),
        ('27', 'No links to other supporting articles'),
        ('28', 'None of the above'), )
    
    feature_aspect_professionalism = MultiSelectField( blank=True, max_length=100, choices=FEATURE_ASPECT, verbose_name = 'Which, if any, features or aspects of a websites design, or of the article therein, reduce your perception of the News websites professionalism?')       
    feature_aspect_bias = MultiSelectField( blank=True, max_length=100, choices=FEATURE_ASPECT, verbose_name = 'Which, if any, features or aspects of a websites design, or of the article therein, increases your perception of the News website’s Bias?')       


                      
                      
                      
                      
                      
                      
                      
          
        
          
          

    MEDIUMS = (
        ('0', 'Television'),
        ('1', 'Radio'),
        ('2', 'Newspaper'),
        ('3', 'Internet'),
        ('4', 'Social Media'), )    
    bias_medium = models.CharField(null=True, blank=True, max_length=100, default=None, choices=MEDIUMS, verbose_name='Please select which News medium you believe is the most Biased?')
    credibility_medium = models.CharField(null=True, blank=True, max_length=100, default=None, choices=MEDIUMS, verbose_name='Please select which news medium you believe is the most Credible?')
    
  
    CRED_MEASURES = (
        ('0', 'Expertise'),
        ('1', 'Trust'),
        ('2', 'Depth of Coverage'),
        ('3', 'Believability'),
        ('4', 'Bias'),
        ('5', 'Fairness'),
        ('6', 'Honesty'),
        ('7', 'Authoritative'),
        ('8', 'Professional'),
        ('9', 'Attractiveness'),
        ('10', 'Interactive'),
        ('11', 'Objective'),
        ('12', 'Completeness'),
        ('13', 'Accuracy'),
        ('14', 'Integrity'),
        ('15', 'Reputation'),
        ('16', 'Successful'),
        ('17', 'Reliability'),
        ('18', 'Informative'),
        ('19', 'Involving'),
        ('20', 'Interesting'),
        ('21', 'Factualness'),
        ('22', 'Comprehension'),
        ('23', 'Currency'),
        ('24', 'Balance'),
        ('25', 'None of the above'),
        ('26', 'Other'),)
    credibility_measures = MultiSelectField( blank=True, max_length=100, choices=CRED_MEASURES, verbose_name = 'When Judging the Credibility of News on the Internet, which of the below dimensions of credibility do you rely on most often? Please select all that apply.')       

       
       
       
       

       
       

    
    
# This is the bit that made the "other" boxes manditory

#===============================================================================
#     def clean(self):
#         if self.party_benefit == 'YES_OTHER' and not self.party_benefit_message:
#             raise ValidationError({'party_benefit_message': ['Required when \"Other\" is checked']})
#         if self.topics == 'OTHER' and not self.topics_message:
#             raise ValidationError({'topics_message': ['Required when \"Other\" is checked']})         
#         if self.deliberate == 'YES_DELIBERATE' and not self.deliberate_message:
#             raise ValidationError({'deliberate_message': ['Required when \"Yes\" is checked']})         
#         if self.elements_features == 'ELEMENTS_YES' and not self.elements_features_message:
#             raise ValidationError({'elements_features_message': ['Required when \"Yes\" is checked']}) 
#         if self.limit_elements_features == 'LIMIT_ELEMENTS_YES' and not self.limit_elements_features_message:
#             raise ValidationError({'limit_elements_features_message': ['Required when \"Yes\" is checked']})         
# 
# 
# 
#  
#             
#                        
# 
#     def __unicode__(self):
#         return unicode(self)
#     
#===============================================================================
        


     
    
    
    
    
    
 
    
    
    
    
    
    
    
    
    
    
    

  