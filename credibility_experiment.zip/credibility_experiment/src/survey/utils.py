#Logic in here


class PathSelection:
    counter = 7
    print counter
    # This simply prints the number seven to your terminal so you can see that it is being called
    
