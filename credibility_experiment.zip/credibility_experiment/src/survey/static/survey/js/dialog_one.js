$("#dialog-message").dialog({
	autoOpen : true,
	modal : true,
	width : 500,
	buttons : {
		"I Understand" : function() {
			$(this).dialog("close");
		}
	}
});
$("#opener").click(function() {
	$("#dialog").dialog("open");
});