
$(function () {
    var initX=0,minX=50,width=400;
    
    var slider = $('#slider'),
        tooltip = $('.tooltip');

    slider.slider({
        min: -50,
        max: +50,
        value: 0,

        start: function (event, ui) {
            tooltip.fadeIn('fast');
        },

        slide: function (event, ui) { 
            var value = slider.slider('value'),
                volume = $('.volume');
            
            console.log(value)
            
            $.post("/surveyone/", {value : value, csrfmiddlewaretoken : '{{csrf_token}}' } );
            
            
            tooltip.css('left', initX+(value*width)/100).text(ui.value); 
        },
        
        stop: function (event, ui) {
        },
    });
    initX=slider.slider("value");

    var txt=initX;
   initX+=(minX*width)/100;
tooltip.css('left',initX).text(txt);
});






















/*
 * $(function () {
    var initX=0,minX=50,width=400;
    //Store frequently elements in variables
    
    
    
    var slider = $('#slider'),
        tooltip = $('.tooltip');

    //Hide the tooltip at first
    //tooltip.hide();
    
    //Call the Slider
    slider.slider({
        //Config
        min: -50,
        max: +50,
        value: 0,

        start: function (event, ui) {
            tooltip.fadeIn('fast');
        },

        //Slider Event
        slide: function (event, ui) { //When the slider is sliding
            var value = slider.slider('value'),
                volume = $('.volume');
            
            
            tooltip.css('left', initX+(value*width)/100).text(ui.value); //Adjust the tooltip accordingly
        },

        stop: function (event, ui) {
          //  tooltip.fadeOut('slow');
        },
    });
    initX=slider.slider("value");
    var txt=initX;
   initX+=(minX*width)/100;
tooltip.css('left',initX).text(txt);
});



 */
