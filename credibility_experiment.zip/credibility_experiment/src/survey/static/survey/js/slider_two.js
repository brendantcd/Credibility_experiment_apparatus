$('#submit').click(function() {
    var username = $('#hidden').val();
    if (username == "") username = 0;
    $.post('comment.php', {
        hidden: username
    }, function(return_data) {
        alert(return_data);
    });
});



$(".slider").slider({
    animate: true,
    range: "min",
    value: 0,
    min: 0,         //Previously you had this set to -100
    max: +100,
    step: 1,

    
    
    //This updates the slider-result below the slider bar so the participant can see their rating
        //Change the first ' ' to '+' if you want to add a Plus sign if the number is above 100
        //It adds a minus sign automatically so you dont need to put this in

    slide: function(event, ui) { 
      $("#slider-result").html((ui.value > 0 ? '' : '') + ui.value);

      
    //My failed attempt at using a ternary conditional operator  
    //  if(ui.value > 0 ? $("#slider-result").addClass('red')) : $("#slider-result").addClass('green')))
      
      if(ui.value < 0) {
          $("#slider-result").removeClass('grey');
          $("#slider-result").addClass('grey');
      }

      if(ui.value > 0) {
          $("#slider-result").removeClass('grey');
          $("#slider-result").addClass('grey');
      }
      
            


          
      
    //This updates the hidden form field which is read by my views.py
        //Change the first ' ' to '+' if you want to add a Plus sign if the number is above 100
        //It adds a minus sign automatically so you dont need to put this in
    if($(this).attr("id") ==  "one")
        $("#hidden1").val((ui.value > 0 ? '' : '') + ui.value);
      
      
    
    
    

    
    
    
   
      
    //This updates the hidden form field "id_0-slider_value"
    //By naming the filed "slider_value" in my forms.py "id_0-" is automatically prepended to it
    //its id then becomes 
    //        <label for="id_0-slider_value">Slider value:</label>
    //So by specifying "id_0-slider_value" here they match
    
    // the below will only insert negative number

    
    
    
 
    
    
    
    if($(this).attr("id") ==  "one")
        $("#id_0-instruction_task_one_value").val(ui.value);
    
    if($(this).attr("id") ==  "one")
        $("#id_1-instruction_task_two_value").val(ui.value);    

    
    
    if($(this).attr("id") ==  "one")
        $("#id_9-spike_one_value").val(ui.value);  

    
    
    if($(this).attr("id") ==  "one")
        $("#id_10-slider_one_value").val(ui.value);  

    if($(this).attr("id") ==  "one")
        $("#id_11-slider_two_value").val(ui.value); 
    
    if($(this).attr("id") ==  "one")
        $("#id_12-slider_three_value").val(ui.value); 
    
    
    
    
    //The DV slider updates are contained in the wizard_form.html page
 

    if($(this).attr("id") ==  "one")
        $("#id_14-slider_four_value").val(ui.value);  

    if($(this).attr("id") ==  "one")
        $("#id_15-slider_five_value").val(ui.value); 
    
    if($(this).attr("id") ==  "one")
        $("#id_16-slider_six_value").val(ui.value); 
    

    
    
    if($(this).attr("id") ==  "one")
        $("#id_18-spike_two_value").val(ui.value);  
    
    
    

    //The DV slider updates are contained in the wizard_form.html page

 

    if($(this).attr("id") ==  "one")
        $("#id_19-slider_seven_value").val(ui.value);  

    if($(this).attr("id") ==  "one")
        $("#id_20-slider_eight_value").val(ui.value); 
    
    if($(this).attr("id") ==  "one")
        $("#id_21-slider_nine_value").val(ui.value); 
    
    
    
    
    
    //The DV slider updates are contained in the wizard_form.html page
  
    
    
    
    
    
    }
});