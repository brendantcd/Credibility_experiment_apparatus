from django.shortcuts import render
from django.db import models
from django.http import Http404
from django.http import HttpResponse
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.utils.decorators import method_decorator

from django.template import RequestContext
from django.shortcuts import render_to_response
from django.core.context_processors import csrf
from django.views.decorators.csrf import csrf_protect

from django.http import HttpResponseRedirect
from django.contrib.formtools.wizard.views import SessionWizardView
import random
#from models import AgeChoice, SexChoice, CountryChoice, StateChoice, RelationshipStatusChoice, SurveyForm
from django.views.generic import TemplateView
from survey.forms import SurveyFormF1

from django.forms import CharField
from django.core import validators

import sys

import logging
logger = logging.getLogger('survey')


from django.db.models import F
from survey.models import SurveyCounter
from survey.models import TotalCounter
from survey.models import URL #THIS IS WHERE IT IS GETTING IT FROM

from itertools import chain

from models import Person

#SURVEY_URLS = ['/surveyone/', '/surveytwo/', '/surveythree/', '/surveyfour/', '/surveyfive/', '/surveysix/', '/surveyseven/', '/surveyeight/', '/surveynine/']






def surveyfull(request):
    return render(request, 'surveyfull.html')
 


def begin(request):

    total_path_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]       
    if total_path_counter.total_max_counter <= 297:

        # bias_experiment_two
        # This makes random_survey_object = to the first object returned when all of the URL objects are returned.
        # An object is a 'key : value' pair e.g. { 'location' : '/surveytwo/'}
        # random_survey_object is a queryset which contains the first or a random list of 'key : value' pair e.g. { 'location' : '/surveytwo/'}
        # It then prints the Value e.g. "/surveytwo/" at its location key. It only has one as it was only made equal to the first one returned at random
        
        random_survey_obj = URL.objects.order_by('?').first()
        print random_survey_obj.location
        print('Random URL = {0}'.format(random_survey_obj.location))
        print random_survey_obj    
    
       
        if random_survey_obj.location == '/surveyone/':    
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_one')[0]
            logger.debug('This is your Survey_wizard_count in one = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >=33: 
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveyone/').exists():
                    survey_urls.filter(location = '/surveyone/').delete()
                    logger.debug("\n\n -------- /surveyone/ has been deleted from queryset -------- \n\n")
                
        elif random_survey_obj.location == '/surveytwo/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_two')[0]
            logger.debug('This is your Survey_wizard_count in two = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33: 
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveytwo/').exists():
                    survey_urls.filter(location = '/surveytwo/').delete()
                    logger.debug("\n\n -------- /surveytwo/ has been deleted from queryset -------- \n\n")
                        
        elif random_survey_obj.location == '/surveythree/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_three')[0]
            logger.debug('This is your Survey_wizard_count in three = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveythree/').exists():
                    survey_urls.filter(location = '/surveythree/').delete()
                    logger.debug("\n\n -------- /surveythree/ has been deleted from queryset -------- \n\n")
                    
        elif random_survey_obj.location == '/surveyfour/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_four')[0]
            logger.debug('This is your Survey_wizard_count in four = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveyfour/').exists():
                    survey_urls.filter(location = '/surveyfour/').delete()
                    logger.debug("\n\n -------- /surveyfour/ has been deleted from queryset -------- \n\n")
                    
        elif random_survey_obj.location == '/surveyfive/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_five')[0]
            logger.debug('This is your Survey_wizard_count in five = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveyfive/').exists():
                    survey_urls.filter(location = '/surveyfive/').delete()
                    logger.debug("\n\n -------- /surveyfive/ has been deleted from queryset -------- \n\n")
                                    
        elif random_survey_obj.location == '/surveysix/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_six')[0]
            logger.debug('This is your Survey_wizard_count in six = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveysix/').exists():
                    survey_urls.filter(location = '/surveysix/').delete()
                    logger.debug("\n\n -------- /surveysix/ has been deleted from queryset -------- \n\n")

        elif random_survey_obj.location == '/surveyseven/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_seven')[0]
            logger.debug('This is your Survey_wizard_count in seven = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveyseven/').exists():
                    survey_urls.filter(location = '/surveyseven/').delete()
                    logger.debug("\n\n -------- /surveyseven/ has been deleted from queryset -------- \n\n")
               
        elif random_survey_obj.location == '/surveyeight/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_eight')[0]
            logger.debug('This is your Survey_wizard_count in eight = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveyeight/').exists():
                    survey_urls.filter(location = '/surveyeight/').delete()
                    logger.debug("\n\n -------- /surveyeight/ has been deleted from queryset -------- \n\n")              

        elif random_survey_obj.location == '/surveynine/':
            survey_path_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_nine')[0]
            logger.debug('This is your Survey_wizard_count in nine = %s', survey_path_counter.survey_wizard_count)
         
            if survey_path_counter.survey_wizard_count >= 33:
                survey_urls = URL.objects.all()
                if survey_urls.filter(location = '/surveynine/').exists():
                    survey_urls.filter(location = '/surveynine/').delete()
                    logger.debug("\n\n -------- /surveynine/ has been deleted from queryset --------\n\n")              
                                           
        return render(request, 'Begin.html', {'survey_url': random_survey_obj.location})    
    else:
        return render(request, 'surveyfull.html')
    
    



def start(request):    
        return render(request, 'Start.html')



class SurveyWizardOne(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardOne, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)       
        
        print "\nYOU ARE ON STEP: %s \n" % step 
        
        
        if step == 0:
            self.request.session['path_one_images'] = ['P1D1.jpg', 'P2D2.jpg', 'P3D3.jpg', 'P4D4.jpg', 'P5D5.jpg', 'P6D6.jpg', 'P7D7.jpg', 'P8D8.jpg', 'P9D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_ONE_IMAGES = self.request.session.get('path_one_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])


        if step in range (0, 30):   
            self.request.session.update({
                                         'path_one_images': PATH_ONE_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })
            
            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)
            
            elif step == 1:                    
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)   
                context['display_image'] = instruction_task_second_image  
                
                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]                                                                                 
                
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]                                                            
                            
                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 9: %s', PATH_ONE_IMAGES)
                first_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 10: %s', PATH_ONE_IMAGES)
                second_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 11: %s', PATH_ONE_IMAGES)
                third_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 13: %s', PATH_ONE_IMAGES)
                fourth_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 14: %s', PATH_ONE_IMAGES)
                fifth_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 15: %s', PATH_ONE_IMAGES)
                sixth_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 18: %s', PATH_ONE_IMAGES)
                seventh_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 19: %s', PATH_ONE_IMAGES)
                eight_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 20: %s', PATH_ONE_IMAGES)
                ninth_image = random.choice(PATH_ONE_IMAGES)   
                PATH_ONE_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')   
                                                                                                                                                
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values)              
                                                                                  
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:               
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                 
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})                               
                                            
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                   
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                   
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)

                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:          
                       
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})     
                                          
            elif step == 18:                           
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)                                                      
                                                                           
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:                  
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_ONE_IMAGES in 22: %s', PATH_ONE_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_one')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
    
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()   
    
                logger.debug('This is your Survey_wizard_count in one = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)        

            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30',]  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context   
            
            
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })
               
   










class SurveyWizardTwo(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardTwo, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_two_images'] = ['P2D1.jpg', 'P3D2.jpg', 'P4D3.jpg', 'P5D4.jpg', 'P6D5.jpg', 'P7D6.jpg', 'P8D7.jpg', 'P9D8.jpg', 'P1D9.jpg']          
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []  
            self.request.session['instruction_task_values'] = []

        PATH_TWO_IMAGES = self.request.session.get('path_two_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])


        if step in range (0, 30):   
            self.request.session.update({
                                         'path_two_images': PATH_TWO_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                        
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)   
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]    

            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 9: %s', PATH_TWO_IMAGES)
                first_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 10: %s', PATH_TWO_IMAGES)
                second_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 11: %s', PATH_TWO_IMAGES)
                third_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 13: %s', PATH_TWO_IMAGES)
                fourth_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 14: %s', PATH_TWO_IMAGES)
                fifth_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 15: %s', PATH_TWO_IMAGES)
                sixth_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 18: %s', PATH_TWO_IMAGES)
                seventh_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 19: %s', PATH_TWO_IMAGES)
                eight_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 20: %s', PATH_TWO_IMAGES)
                ninth_image = random.choice(PATH_TWO_IMAGES)   
                PATH_TWO_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')                 
                                                                                                                        
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                       
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')  
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})       
                             
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})     
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_TWO_IMAGES in 22: %s', PATH_TWO_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_two')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0] 
                total_counter.total_max_counter += 1
                total_counter.save()   
                 
                logger.debug('This is your Survey_wizard_count in two = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                                
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               

    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        }) 
        
        

class SurveyWizardThree(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardThree, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_three_images'] = ['P3D1.jpg', 'P4D2.jpg', 'P5D3.jpg', 'P6D4.jpg', 'P7D5.jpg', 'P8D6.jpg', 'P9D7.jpg', 'P1D8.jpg', 'P2D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_THREE_IMAGES = self.request.session.get('path_three_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_three_images': PATH_THREE_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)   
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]   
           
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 9: %s', PATH_THREE_IMAGES)
                first_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 10: %s', PATH_THREE_IMAGES)
                second_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 11: %s', PATH_THREE_IMAGES)
                third_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 13: %s', PATH_THREE_IMAGES)
                fourth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 14: %s', PATH_THREE_IMAGES)
                fifth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 15: %s', PATH_THREE_IMAGES)
                sixth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 18: %s', PATH_THREE_IMAGES)
                seventh_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 19: %s', PATH_THREE_IMAGES)
                eight_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 20: %s', PATH_THREE_IMAGES)
                ninth_image = random.choice(PATH_THREE_IMAGES)   
                PATH_THREE_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')
                                                                                                                     
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                       
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')  
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})          
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                    
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})     
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],})  
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_THREE_IMAGES in 22: %s', PATH_THREE_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_three')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in three = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                                
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
                       
        return context 


    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })
        
                       

class SurveyWizardFour(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardFour, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_four_images'] = ['P4D1.jpg', 'P5D2.jpg', 'P6D3.jpg', 'P7D4.jpg', 'P8D5.jpg', 'P9D6.jpg', 'P1D7.jpg', 'P2D8.jpg', 'P3D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_FOUR_IMAGES = self.request.session.get('path_four_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_four_images': PATH_FOUR_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,                                         
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)   
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]    
                
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 9: %s', PATH_FOUR_IMAGES)
                first_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 10: %s', PATH_FOUR_IMAGES)
                second_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 11: %s', PATH_FOUR_IMAGES)
                third_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 13: %s', PATH_FOUR_IMAGES)
                fourth_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 14: %s', PATH_FOUR_IMAGES)
                fifth_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 15: %s', PATH_FOUR_IMAGES)
                sixth_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 18: %s', PATH_FOUR_IMAGES)
                seventh_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 19: %s', PATH_FOUR_IMAGES)
                eight_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 20: %s', PATH_FOUR_IMAGES)
                ninth_image = random.choice(PATH_FOUR_IMAGES)   
                PATH_FOUR_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')
                                                                                                                               
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                      
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')  
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})          
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})     
                                                                                                                                           
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_FOUR_IMAGES in 22: %s', PATH_FOUR_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_four')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in four = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                                       
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        }) 
        
                
      
class SurveyWizardFive(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardFive, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_five_images'] = ['P5D1.jpg', 'P6D2.jpg', 'P7D3.jpg', 'P8D4.jpg', 'P9D5.jpg', 'P1D6.jpg', 'P2D7.jpg', 'P3D8.jpg', 'P4D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_FIVE_IMAGES = self.request.session.get('path_five_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

   
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_five_images': PATH_FIVE_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)     
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)

                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0] 
                                               
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]    

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 9: %s', PATH_FIVE_IMAGES)
                first_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 10: %s', PATH_FIVE_IMAGES)
                second_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 11: %s', PATH_FIVE_IMAGES)
                third_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 13: %s', PATH_FIVE_IMAGES)
                fourth_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 14: %s', PATH_FIVE_IMAGES)
                fifth_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 15: %s', PATH_FIVE_IMAGES)
                sixth_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 18: %s', PATH_FIVE_IMAGES)
                seventh_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 19: %s', PATH_FIVE_IMAGES)
                eight_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 20: %s', PATH_FIVE_IMAGES)
                ninth_image = random.choice(PATH_FIVE_IMAGES)   
                PATH_FIVE_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')   
                                                                                                                               
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                       
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})           
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})    
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_FIVE_IMAGES in 22: %s', PATH_FIVE_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_five')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in five = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                        
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })
       
       
              
class SurveyWizardSix(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardSix, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_six_images'] = ['P6D1.jpg', 'P7D2.jpg', 'P8D3.jpg', 'P9D4.jpg', 'P1D5.jpg', 'P2D6.jpg', 'P3D7.jpg', 'P4D8.jpg', 'P5D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_SIX_IMAGES = self.request.session.get('path_six_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_six_images': PATH_SIX_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)     
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0] 
               
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]                                                            
                            
                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 9: %s', PATH_SIX_IMAGES)
                first_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 10: %s', PATH_SIX_IMAGES)
                second_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 11: %s', PATH_SIX_IMAGES)
                third_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 13: %s', PATH_SIX_IMAGES)
                fourth_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 14: %s', PATH_SIX_IMAGES)
                fifth_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 15: %s', PATH_SIX_IMAGES)
                sixth_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 18: %s', PATH_SIX_IMAGES)
                seventh_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 19: %s', PATH_SIX_IMAGES)
                eight_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 20: %s', PATH_SIX_IMAGES)
                ninth_image = random.choice(PATH_SIX_IMAGES)   
                PATH_SIX_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                                                                                                                                  
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                       
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:
                
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})         
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})     
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_SIX_IMAGES in 22: %s', PATH_SIX_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
               
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   

                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })
                
                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_six')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in six = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                                           
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })



class SurveyWizardSeven(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardSeven, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_seven_images'] = ['P7D1.jpg', 'P8D2.jpg', 'P9D3.jpg', 'P1D4.jpg', 'P2D5.jpg', 'P3D6.jpg', 'P4D7.jpg', 'P5D8.jpg', 'P6D9.jpg']   
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_SEVEN_IMAGES = self.request.session.get('path_seven_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])
        
        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_seven_images': PATH_SEVEN_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)     
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]     
              
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 9: %s', PATH_SEVEN_IMAGES)
                first_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 10: %s', PATH_SEVEN_IMAGES)
                second_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 11: %s', PATH_SEVEN_IMAGES)
                third_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 13: %s', PATH_SEVEN_IMAGES)
                fourth_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 14: %s', PATH_SEVEN_IMAGES)
                fifth_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 15: %s', PATH_SEVEN_IMAGES)
                sixth_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 18: %s', PATH_SEVEN_IMAGES)
                seventh_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 19: %s', PATH_SEVEN_IMAGES)
                eight_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 20: %s', PATH_SEVEN_IMAGES)
                ninth_image = random.choice(PATH_SEVEN_IMAGES)   
                PATH_SEVEN_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image')
                                                                                                                               
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                      
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:
                
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})          
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})  
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)  
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_SEVEN_IMAGES in 22: %s', PATH_SEVEN_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_seven')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in seven = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                        
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })   



class SurveyWizardEight(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardEight, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_eight_images'] = ['P8D1.jpg', 'P9D2.jpg', 'P1D3.jpg', 'P2D4.jpg', 'P3D5.jpg', 'P4D6.jpg', 'P5D7.jpg', 'P6D8.jpg', 'P7D9.jpg']    
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_EIGHT_IMAGES = self.request.session.get('path_eight_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_eight_images': PATH_EIGHT_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)     
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]    
             
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 9: %s', PATH_EIGHT_IMAGES)
                first_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 10: %s', PATH_EIGHT_IMAGES)
                second_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 11: %s', PATH_EIGHT_IMAGES)
                third_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 13: %s', PATH_EIGHT_IMAGES)
                fourth_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 14: %s', PATH_EIGHT_IMAGES)
                fifth_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 15: %s', PATH_EIGHT_IMAGES)
                sixth_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 18: %s', PATH_EIGHT_IMAGES)
                seventh_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 19: %s', PATH_EIGHT_IMAGES)
                eight_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 20: %s', PATH_EIGHT_IMAGES)
                ninth_image = random.choice(PATH_EIGHT_IMAGES)   
                PATH_EIGHT_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                                                                                                                                 
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                             
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:
                
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})         
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                    
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})  
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],}) 
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                    
                logger.debug('\n\nThis is the available list of PATH_EIGHT_IMAGES in 22: %s', PATH_EIGHT_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_eight')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in eight = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                               
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })



class SurveyWizardNine(SessionWizardView):                             
    def get_context_data(self, form, **kwargs):
        context = super(SurveyWizardNine, self).get_context_data(form, **kwargs)                      
        step = int(self.steps.current)        

        print "YOU ARE ON STEP:", step

        if step == 0:
            self.request.session['path_nine_images'] = ['P9D1.jpg', 'P1D2.jpg', 'P2D3.jpg', 'P3D4.jpg', 'P4D5.jpg', 'P5D6.jpg', 'P6D7.jpg', 'P7D8.jpg', 'P8D9.jpg']   
            self.request.session['instruction_task_one_images'] = ['IT1A.jpg', 'IT1B.jpg', 'IT1C.jpg']    
            self.request.session['instruction_task_two_images'] = ['IT2A.jpg', 'IT2B.jpg', 'IT2C.jpg']    
            self.request.session['images'] = []
            self.request.session['slider_DV_values'] = []
            self.request.session['instruction_task_values'] = []

        PATH_NINE_IMAGES = self.request.session.get('path_nine_images', [])        
        images = self.request.session.get('images', [])
        slider_DV_values = self.request.session.get('slider_DV_values', [])
        instruction_task_values = self.request.session.get('instruction_task_values', [])
        INSTRUCTION_TASK_ONE_IMAGES = self.request.session.get('instruction_task_one_images', [])
        INSTRUCTION_TASK_TWO_IMAGES = self.request.session.get('instruction_task_two_images', [])

        
        if step in range (0, 30):   
            self.request.session.update({
                                         'path_nine_images': PATH_NINE_IMAGES,
                                         'images': images,
                                         'slider_DV_values': slider_DV_values,
                                         'instruction_task_values' : instruction_task_values,
                                         'instruction_task_one_images': INSTRUCTION_TASK_ONE_IMAGES,
                                         'instruction_task_two_images': INSTRUCTION_TASK_TWO_IMAGES
                                         })

            if step == 0:
                logger.debug('\n\nThis is your Instruction Task One page')
                instruction_task_first_image = random.choice(INSTRUCTION_TASK_ONE_IMAGES)     
                context['display_image'] = instruction_task_first_image                                 
                logger.debug('\n\n\nThis is your instruction_task_values in 0 %s', instruction_task_values)

            elif step == 1:
                logger.debug('\n\nThis is your Instruction Task Two page')
                instruction_task_second_image = random.choice(INSTRUCTION_TASK_TWO_IMAGES)    
                context['display_image'] = instruction_task_second_image  

                #This gets the first instruction task value from the template from the "slider_value" input
                #It then inserts it into instruction_task_values             
                #This code currently has no value but I might need it
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(0, slider_value) 
                logger.debug('\n\n\nThis is your instruction_task_values in 1 %s', instruction_task_values)
 
                #This is designed to send the value back to the wizard_form so it can be submitted to the DB
                context['instruction_task_one_value'] = instruction_task_values[0]
           
            elif step == 2:              
                #This is to save the instruction task values
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    instruction_task_values.insert(1, slider_value)  
                logger.debug('\n\n\nThis is your instruction_task_values in 2 %s', instruction_task_values)  
                context['instruction_task_two_value'] = instruction_task_values[1]   

                # This is to assign all the values for the images
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 9: %s', PATH_NINE_IMAGES)
                first_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(first_image)                
                images.insert(0, first_image)   
                logger.debug('\nThis is your images list: %s', images)

                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 10: %s', PATH_NINE_IMAGES)
                second_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(second_image)
                images.insert(1, second_image)   
                logger.debug('\nThis is your images list: %s', images)
                                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 11: %s', PATH_NINE_IMAGES)
                third_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(third_image)
                images.insert(2, third_image)   
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 13: %s', PATH_NINE_IMAGES)
                fourth_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(fourth_image)               
                images.insert(3, fourth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 14: %s', PATH_NINE_IMAGES)
                fifth_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(fifth_image)
                images.insert(4, fifth_image)                
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 15: %s', PATH_NINE_IMAGES)
                sixth_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(sixth_image)
                images.insert(5, sixth_image)                 
                logger.debug('\nThis is your images list: %s', images)
                
                
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 18: %s', PATH_NINE_IMAGES)
                seventh_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(seventh_image)               
                images.insert(6, seventh_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 19: %s', PATH_NINE_IMAGES)
                eight_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(eight_image)
                images.insert(7, eight_image)  
                logger.debug('\nThis is your images list: %s', images)
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 20: %s', PATH_NINE_IMAGES)
                ninth_image = random.choice(PATH_NINE_IMAGES)   
                PATH_NINE_IMAGES.remove(ninth_image)
                images.insert(8, ninth_image)
                logger.debug('\nThis is your images list: %s', images)
                

                # This is necessary to make the session object e.g. first_image = to the result of the 
                # random generated 
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                
                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')  

                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                                                                                                                                       
            elif step == 10:                                    
                context['display_image'] = images[0]                                 

                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                                                       
                logger.debug('\n\n\nThis is your slider_DV_values in 10 %s', slider_DV_values) 
                                                       
            elif step == 11:            
                context['display_image'] = images[1]                                  

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                 
                logger.debug('\nThis is your images list in 11: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(0, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 11 %s', slider_DV_values)
                                                                         
            elif step == 12:
                context['display_image'] = images[2]                                

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')   
                                 
                logger.debug('\nThis is your images list in 12: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(1, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 12 %s', slider_DV_values)
                                                                               
            elif step == 13:
                
                self.request.session['first_image'] = images[0] 
                self.request.session.get('first_image')                     

                self.request.session['second_image'] = images[1] 
                self.request.session.get('second_image')                                                   

                self.request.session['third_image'] = images[2] 
                self.request.session.get('third_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(2, slider_value)
                          
                logger.debug('\nThis is your images list in 13: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 13 %s', slider_DV_values)
    
                context.update({'first_image' : self.request.session['first_image'],
                                'second_image' : self.request.session['second_image'],
                                'third_image' : self.request.session['third_image'],                 
                                'first_slider' : slider_DV_values[0],
                                'second_slider' : slider_DV_values[1],
                                'third_slider' : slider_DV_values[2],})          
                         
            elif step == 14:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(0)                
                    slider_DV_values.insert(0, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(1)                
                    slider_DV_values.insert(1, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(2)                
                    slider_DV_values.insert(2, slider_value3)
                                    
                context['display_image'] = images[3]                                                           

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')  
                                
                logger.debug('\n\n\This is your fourth image %s', images[3])
                logger.debug('\nThis is your images list in 14: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 14 %s', slider_DV_values)
                                                                                           
            elif step == 15:
                context['display_image'] = images[4]                                  

                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')  
                
                logger.debug('\n\nThis is your fifth image %s', images[4])
                logger.debug('\nThis is your images list in 15: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(3, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 15 %s', slider_DV_values)
                                                                        
            elif step == 16:
                context['display_image'] = images[5]                                  

                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image') 
                  
                logger.debug('\n\nThis is your sixth image %s', images[5])
                logger.debug('\nThis is your images list in 16: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(4, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 16 %s', slider_DV_values)
                                                                      
            elif step == 17:                 

                self.request.session['fourth_image'] = images[3] 
                self.request.session.get('fourth_image')                 
                
                self.request.session['fifth_image'] = images[4] 
                self.request.session.get('fifth_image')    
                
                self.request.session['sixth_image'] = images[5] 
                self.request.session.get('sixth_image')
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(5, slider_value)  

                logger.debug('\nThis is your images list in 17: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 17 %s', slider_DV_values)

                context.update({'fourth_image' : self.request.session['fourth_image'],
                                'fifth_image' : self.request.session['fifth_image'],
                                'sixth_image' : self.request.session['sixth_image'],
                                'first_slider' : slider_DV_values[3],
                                'second_slider' : slider_DV_values[4],
                                'third_slider' : slider_DV_values[5],})   
                                                                       
            elif step == 18:                            
                #This is where I am trying to update my slider values on DV    
                #This is the spike 2 page                
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
               
                if slider_value1 != '':
                    slider_DV_values.pop(3)                
                    slider_DV_values.insert(3, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(4)                
                    slider_DV_values.insert(4, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(5)                
                    slider_DV_values.insert(5, slider_value3)
            
            elif step == 19:
                context['display_image'] = images[6]                                  
 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image')  
                                                        
                logger.debug('\n\n\This is your seventh image %s', images[6])
                logger.debug('\nThis is your images list in 19: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 19 %s', slider_DV_values)
                                                       
            elif step == 20:
                context['display_image'] = images[7]                                 
   
                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 
                                
                logger.debug('\n\nThis is your eight image %s', images[7])
                logger.debug('\nThis is your images list in 20: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(6, slider_value) 

                logger.debug('\n\n\nThis is your slider_DV_values in 20 %s', slider_DV_values)
                                                
            elif step == 21:
                context['display_image'] = images[8]                                  

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                 
                logger.debug('\n\nThis is your ninth image %s', images[8])
                logger.debug('\nThis is your images list in 21: %s', images)

                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:                
                    slider_DV_values.insert(7, slider_value)
                    
                logger.debug('\n\n\nThis is your slider_DV_values in 21 %s', slider_DV_values)
                                                                       
            elif step == 22:                                 
                self.request.session['seventh_image'] = images[6] 
                self.request.session.get('seventh_image') 

                self.request.session['eight_image'] = images[7] 
                self.request.session.get('eight_image') 

                self.request.session['ninth_image'] = images[8] 
                self.request.session.get('ninth_image') 
                
                slider_value = self.request.POST.get('slider_value')
                if slider_value is not None:
                    slider_DV_values.insert(8, slider_value)
                
                logger.debug('\nThis is your images list in 22: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 22 %s', slider_DV_values)
                      
                context.update({'seventh_image' : self.request.session['seventh_image'],
                                'eight_image' : self.request.session['eight_image'],
                                'ninth_image' : self.request.session['ninth_image'],                 
                                'first_slider' : slider_DV_values[6],  
                                'second_slider' : slider_DV_values[7],
                                'third_slider' : slider_DV_values[8],})  
   
            elif step == 23:
                #This is where I am trying to update my slider values on DV            
                slider_value1 = self.request.POST.get('slider_value1')
                slider_value2 = self.request.POST.get('slider_value2')
                slider_value3 = self.request.POST.get('slider_value3')
                           
                if slider_value1 != '':
                    slider_DV_values.pop(6)                
                    slider_DV_values.insert(6, slider_value1)
                
                if slider_value2 != '':
                    slider_DV_values.pop(7)                
                    slider_DV_values.insert(7, slider_value2)
                
                if slider_value3 != '':
                    slider_DV_values.pop(8)                
                    slider_DV_values.insert(8, slider_value3)
                
                logger.debug('\n\nThis is the available list of PATH_NINE_IMAGES in 22: %s', PATH_NINE_IMAGES)
                logger.debug('\nThis is your images list in 23: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 23 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           }) 

            elif step == 24:
                logger.debug('\nThis is your images list in 24: %s', images)
                logger.debug('\n\n\nThis is your slider_DV_values in 24 %s', slider_DV_values)

                print 'The first image is: %s. Its rating is: %s' % (images[0], slider_DV_values[0]) 
                print 'The second image is: %s. Its rating is: %s' % (images[1], slider_DV_values[1]) 
                print 'The third image is: %s. Its rating is: %s' % (images[2], slider_DV_values[2])  
                print 'The forth image is: %s. Its rating is: %s' % (images[3], slider_DV_values[3]) 
                print 'The fifth image is: %s. Its rating is: %s' % (images[4], slider_DV_values[4]) 
                print 'The sixth image is: %s. Its rating is: %s' % (images[5], slider_DV_values[5]) 
                print 'The seventh image is: %s. Its rating is: %s' % (images[6], slider_DV_values[6]) 
                print 'The eight image is: %s. Its rating is: %s' % (images[7], slider_DV_values[7]) 
                print 'The ninth image is: %s. Its rating is: %s' % (images[8], slider_DV_values[8])                   
                   
                context.update({'first_image' : images[0],
                           'second_image' : images[1],
                           'third_image' : images[2],
                           'fourth_image' : images[3],
                           'fifth_image' : images[4],
                           'sixth_image' : images[5],
                           'seventh_image' : images[6],
                           'eight_image' : images[7],
                           'ninth_image' : images[8], 
                           })

                survey_counter = SurveyCounter.objects.get_or_create(survey_wizard_type = 'survey_wizard_nine')[0]
                survey_counter.survey_wizard_count += 1 
                survey_counter.save()
        
                total_counter = TotalCounter.objects.get_or_create(total_max_counter__gte=0)[0]
                total_counter.total_max_counter += 1
                total_counter.save()        
                
                logger.debug('This is your Survey_wizard_count in nine = %s', survey_counter.survey_wizard_count)
                logger.debug('This is your total_max_count = %s', total_counter.total_max_counter)
                               
            # Remember if you change these you have to change your JavaScript
            steps = ['10','11','12','14','15','16','19','20','21']              
            it_step_one = ['0']
            it_step_two = ['1']
            spike1 = ['9']
            spike2 = ['18']
            dv_steps = ['13','17','22',]  
            dv_nine_positive = ['23']       
            dv_nine_negative = ['24'] 
            no_next_button = ['2', '8', '25']
           # next_button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  
            button = ['0','1','3','4','5','6','7','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','26','27','28','29','30']  

                                                                                                             
            context.update({'steps' : steps,
                            'it_step_one' : it_step_one, 
                            'it_step_two' : it_step_two,
                            'spike1' : spike1,
                            'spike2' : spike2,
                            'dv_steps' : dv_steps, 
                            'dv_nine_positive' : dv_nine_positive, 
                            'dv_nine_negative' : dv_nine_negative,
                            'no_next_button' : no_next_button,
                            'button' : button,
                           # 'next_button' : next_button,
                            })
               
        return context 
               
   
    def done(self, form_list, **kwargs):
        
        print "This is your done method"
        
        data = {k: v for form in form_list for k, v in form.cleaned_data.items()}
        
        instance = Person.objects.create(**data)
        return render(self.request, 'Return_to_Prolific_Academic.html', {
            'form_data': [form.cleaned_data for form in form_list],            
        })



def survey(request):

    age = AgeChoice()
    sex = SexChoice()
    origin = CountryChoice()    
    state = StateChoice()
    relationship = RelationshipStatusChoice()   


    return render(request, 'survey.html', {
                                           'age': age,
                                           'sex': sex,
                                           'origin': origin,
                                           'state': state,
                                           'relationship': relationship,     
                                           })




def surveytwo(request):
    form = SurveyForm()
    return render(request, 'surveytwo.html', {'form': form})

def jquerytest(request):
    return render(request, 'jquery_test_page.html')


class ContactWizard(SessionWizardView):
    def done(self, form_list, **kwargs):
        return render_to_response('done.html', {
            'form_data': [form.cleaned_data for form in form_list],
        })



def hello(request):
    return HttpResponse("Hello world")




def slideview(request):
    jquery_slider = Slider()   
    return render(request, 'slider_two.html', {
                                           'form': jquery_slider,  
                                           })



def slide_test(request):
    #jquery_slider = Slider()
    
    temp = request.session._session_key  
    print temp

    return render_to_response('slide_test.html')





def my_view(request):
    return render_to_response('my_template.html', {}, context_instance=RequestContext(request))


def sview(request):
    jquery_slider = Slider()
    native_slider = SlideForm()
    return render(request, "slider_one.html", {
                                               'jquery_slider':jquery_slider,
                                               'native_slider':native_slider})


