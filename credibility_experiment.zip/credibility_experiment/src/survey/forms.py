from django import forms
from django.forms import ModelForm, Textarea, extras, RadioSelect, IntegerField




from django.forms.extras import SelectDateWidget
from django.forms.extras import *
from survey.models import Person
from django.core import validators
import random
from django.forms.util import ErrorList
from itertools import chain
from django.utils.encoding import force_unicode




class RadioSelectNotNull(RadioSelect):
    def get_renderer(self, name, value, attrs=None, choices=()):
        """Returns an instance of the renderer."""
        if value is None: value = ''
        str_value = force_unicode(value) # Normalize to string.
        final_attrs = self.build_attrs(attrs)
        choices = list(chain(self.choices, choices))
        if choices[0][0] == '':
            choices.pop(0)
        return self.renderer(name, str_value, final_attrs, choices)


class SurveyFormIT1(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['instruction_task_one_value', 'instruction_task_one_image']
        widgets = {'instruction_task_one_value' : forms.HiddenInput,
                   'instruction_task_one_image' : forms.HiddenInput}       
                    
class SurveyFormIT2(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['instruction_task_two_value', 'instruction_task_two_image']
        widgets = {'instruction_task_two_value' : forms.HiddenInput,
                   'instruction_task_two_image' : forms.HiddenInput}      






class Start(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['start']
        widgets = {'start' : forms.HiddenInput}
        


class SurveyFormReflect(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['reflect']
        widgets = {'reflect' : forms.HiddenInput}
        
        
        
class SurveyFormRate(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['rate']
        widgets = {'rate' : forms.HiddenInput}
        
        
class Submit(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['submit']
        widgets = {'submit' : forms.HiddenInput}
           
                
        
                
class SurveyFormA(forms.ModelForm):
    
    birthdate = forms.DateField(widget=extras.SelectDateWidget(years=range(1920, 1999)), required=False)

    class Meta:
        model = Person
        fields = ['prolific_academic_ID', 'birthdate', 'sex', 'marital_status', 'state']
        
class SurveyFormB(forms.ModelForm): 
    class Meta:
        model = Person
        fields = ['internet_usage', 'smart_phone_ownership', 'smart_phone_usage']        
        widgets = {'internet_usage' : RadioSelectNotNull,
                   'smart_phone_ownership' : RadioSelectNotNull,
                   'smart_phone_usage' : RadioSelectNotNull,}

class SurveyFormC(forms.ModelForm):   
    class Meta:
        model = Person
        fields = ['education', 'wages', 'presentage_savings', 'occupation']         
        widgets = {'education' : RadioSelectNotNull,
                   'wages' : RadioSelectNotNull,
                   'presentage_savings' : RadioSelectNotNull,
                   'occupation' : RadioSelectNotNull,}
      
class SurveyFormD(forms.ModelForm): # Political Viewpoints
    class Meta:
        model = Person
        fields = ['political_leaning', 'democrat_republican', 'voting_rights', 'election']             
        widgets = {'political_leaning' : RadioSelectNotNull,
                   'democrat_republican' : RadioSelectNotNull,
                   'voting_rights' : RadioSelectNotNull,
                   'election' : forms.CheckboxSelectMultiple,}
                
class SurveyFormE(forms.ModelForm): #News Access Questions
    class Meta:
        model = Person
        fields = ['news_access', 'news_access_times']        
        widgets = {'news_access' : forms.CheckboxSelectMultiple,
                   'news_access_times' : RadioSelectNotNull,}

         
class SurveyFormSpike1(forms.ModelForm):           
    class Meta:
        model = Person    
        fields = ['spike_one_value', 'spike_one_image']
        widgets = {'spike_one_value' : forms.HiddenInput,
                   'spike_one_image' : forms.HiddenInput}  
        
        
class SurveyFormF1(forms.ModelForm):      
    class Meta:
        model = Person       
        fields = ['slider_one_value', 'slider_one_image']
        widgets = {'slider_one_value' : forms.HiddenInput,
                   'slider_one_image' : forms.HiddenInput}   
        
class SurveyFormF2(forms.ModelForm):        
    class Meta:
        model = Person        
        fields = ['slider_two_value', 'slider_two_image']
        widgets = {'slider_two_value' : forms.HiddenInput,
                   'slider_two_image' : forms.HiddenInput}   
        
class SurveyFormF3(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['slider_three_value', 'slider_three_image']
        widgets = {'slider_three_value' : forms.HiddenInput,
                   'slider_three_image' : forms.HiddenInput}  
             
             
             
             
class SurveyFormDV1(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['DV_one_value', 'DV_two_value', 'DV_three_value']
        
        widgets = {'DV_one_value' : forms.HiddenInput,
                   'DV_two_value' : forms.HiddenInput,
                   'DV_three_value' : forms.HiddenInput}          
            
            
            
            
            
            
            
            
            
            
class SurveyFormF4(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['slider_four_value', 'slider_four_image']
        widgets = {'slider_four_value' : forms.HiddenInput,
                   'slider_four_image' : forms.HiddenInput}    
           
class SurveyFormF5(forms.ModelForm):        
    class Meta:
        model = Person        
        fields = ['slider_five_value', 'slider_five_image']
        widgets = {'slider_five_value' : forms.HiddenInput,
                   'slider_five_image' : forms.HiddenInput}   
        
class SurveyFormF6(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['slider_six_value', 'slider_six_image']
        widgets = {'slider_six_value' : forms.HiddenInput,
                   'slider_six_image' : forms.HiddenInput}  
        
            
        
        
        
        
        

        
     
           
         
class SurveyFormDV2(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['DV_four_value', 'DV_five_value', 'DV_six_value']
        widgets = {'DV_four_value' : forms.HiddenInput,
                   'DV_five_value' : forms.HiddenInput,
                   'DV_six_value' : forms.HiddenInput} 




class SurveyFormSpike2(forms.ModelForm):      
    class Meta:
        model = Person    
        fields = ['spike_two_value', 'spike_two_image']
        widgets = {'spike_two_value' : forms.HiddenInput,
                   'spike_two_image' : forms.HiddenInput}  
        
        
                
        
        
        
        
            
            
            
class SurveyFormF7(forms.ModelForm):        
    class Meta:
        model = Person        
        fields = ['slider_seven_value', 'slider_seven_image']
        widgets = {'slider_seven_value' : forms.HiddenInput,
                   'slider_seven_image' : forms.HiddenInput}   
        
class SurveyFormF8(forms.ModelForm):       
    class Meta:
        model = Person       
        fields = ['slider_eight_value', 'slider_eight_image']
        widgets = {'slider_eight_value' : forms.HiddenInput,
                   'slider_eight_image' : forms.HiddenInput}   
        
class SurveyFormF9(forms.ModelForm):        
    class Meta:
        model = Person        
        fields = ['slider_nine_value', 'slider_nine_image']
        widgets = {'slider_nine_value' : forms.HiddenInput,
                   'slider_nine_image' : forms.HiddenInput}   
        
        
        
        
class SurveyFormDV3(forms.ModelForm):       
    class Meta:
        model = Person        
        fields = ['DV_seven_value', 'DV_eight_value', 'DV_nine_value']
        widgets = {'DV_seven_value' : forms.HiddenInput,
                   'DV_eight_value' : forms.HiddenInput,
                   'DV_nine_value' : forms.HiddenInput} 
        
        
        
        
        
        
        
        
          
   
class SurveyFormDV4(forms.ModelForm):          
    class Meta:
        model = Person       
        fields = ['DV_positive']
        widgets = {'DV_positive' : forms.HiddenInput}
        
        
                
        
        

class SurveyFormDV5(forms.ModelForm):     
    class Meta:
        model = Person        
        fields = ['DV_negative']
        widgets = {'DV_negative' : forms.HiddenInput}
        
        
       
        
        
   

class SurveyFormG(forms.ModelForm): #Reflective Questions
    class Meta:
        model = Person
        
        fields = ['websites_recognised', 'websites_bised']        
        widgets = {'bias_medium' : forms.CheckboxSelectMultiple,
                   'gender' : forms.CheckboxSelectMultiple,} 
        
         
         

class SurveyFormH(forms.ModelForm): #Reflective Questions
    class Meta:
        model = Person
        
        fields = ['design_impact_perception_of_bias_website', 'design_impact_perception_of_bias_organsiation', 'links_impact_perception_of_bias_organsiation', 'links_impact_perception_of_professionalism_organsiation']        
        widgets = {'design_impact_perception_of_bias_website' : RadioSelectNotNull,
                   'design_impact_perception_of_bias_organsiation' : RadioSelectNotNull,
                   'links_impact_perception_of_bias_organsiation' : RadioSelectNotNull,
                   'links_impact_perception_of_professionalism_organsiation' : RadioSelectNotNull,}
           

class SurveyFormI(forms.ModelForm):
    class Meta:
        model = Person
        
        fields = ['feature_aspect_professionalism', 'feature_aspect_bias']        
        widgets = {'feature_aspect_professionalism' : forms.CheckboxSelectMultiple,
                   'feature_aspect_bias' : forms.CheckboxSelectMultiple,}           

class SurveyFormJ(forms.ModelForm):
    class Meta:
        model = Person
        
        fields = ['credibility_medium', 'bias_medium', 'credibility_measures']        
        widgets = {'credibility_medium' : RadioSelectNotNull,
                   'bias_medium' : RadioSelectNotNull,
                   'credibility_measures' : forms.CheckboxSelectMultiple,}   
     
        

        
