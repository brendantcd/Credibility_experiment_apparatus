import os.path

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
BASE_DIR = os.path.dirname(os.path.dirname(__file__))


#Your template directories                    
TEMPLATE_DIRS = ( 

                 '/Users/user/Dropbox/workspace/credibility_experiment/src/survey/templates/survey',
                 '/Users/user/Dropbox/workspace/credibility_experiment/src/templates/',

)


TEMPLATE_CONTEXT_PROCESSORS = (
                "django.contrib.auth.context_processors.auth",
                "django.core.context_processors.debug",
                "django.core.context_processors.i18n",
                "django.core.context_processors.media",
                "django.core.context_processors.static",
                "django.core.context_processors.tz",
                "django.contrib.messages.context_processors.messages",   
                "django.core.context_processors.request",
                "django.core.context_processors.csrf", #This is for CSRF protection with RequestContext and possibly render
                                     
)

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.6/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'yourSecretKey'

DEBUG = True



TEMPLATE_DEBUG = True



INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',
    'django.contrib.flatpages',
    'survey',)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ROOT_URLCONF = 'credibility_experiment.urls'

WSGI_APPLICATION = 'credibility_experiment.wsgi.application'

DATABASES = {
    'default': { 
        'ENGINE': 'django.db.backends.mysql', 
        'NAME': 'yourDatabasename',                                       
        'USER': 'root',
        'PASSWORD': 'yourDatabasepassword',
        'HOST': '127.0.0.1',
        #'PORT': '', 
    }
}

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Europe/Dublin'
USE_I18N = True
USE_L10N = False
USE_TZ = True
DATE_FORMAT = 'YNj'  # Year(4 digit) Month(long) Day

SITE_ID = 2
  
# These are my deployment static dirs
STATIC_ROOT = '/var/www/credibility_experiment/static/'                         #This is where they are collected to
STATIC_URL = '/credibility_experiment/static/'                                  #This becomes the new URL for my static files
STATICFILES_DIRS = (                                                            #This is where they are collected from
                    '/var/www/credibility_experiment/src/survey/static/survey/css', 
                    '/var/www/credibility_experiment/src/survey/static/survey/js', 
                    '/var/www/credibility_experiment/src/survey/static/survey/fonts', 
                    '/var/www/credibility_experiment/src/survey/static/survey/images', 
)

 
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format' : "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s",
            'datefmt' : "%d/%b/%Y %H:%M:%S"
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
    },
    'handlers': {
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            #'filename': os.path.join(DJANGO_ROOT, 'survey.log'),
            'filename': 'survey.log',
            
            # you really need to get the os.path thing working - should DJANGO_ROOT be scr???
            
            #'filename': '/var/www/credibility_experiment/src/logs/survey.log',
            'formatter': 'verbose'
        },
    },
    'loggers': {
        #=======================================================================
        # 'django': {
        #     'handlers':['file'],
        #     'propagate': True,
        #     'level':'DEBUG',
        # },
        #=======================================================================
        'survey': {
            'handlers': ['file'],
            'level': 'DEBUG',
        },
    }
}





