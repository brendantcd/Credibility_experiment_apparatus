from django.conf.urls import patterns, include, url
from django.contrib import admin
admin.autodiscover()
from django.views.generic import TemplateView



from survey import views as survey_views 
from survey.views import SurveyWizardOne, SurveyWizardTwo, SurveyWizardThree, SurveyWizardFour, SurveyWizardFive, SurveyWizardSix, SurveyWizardSeven, SurveyWizardEight, SurveyWizardNine
from survey.forms import SurveyFormIT1, SurveyFormIT2, Start, SurveyFormA, SurveyFormB, SurveyFormC, SurveyFormD, SurveyFormE, SurveyFormRate, SurveyFormSpike1, SurveyFormF1, SurveyFormF2, SurveyFormF3, SurveyFormF4, SurveyFormF5, SurveyFormF6, SurveyFormSpike2, SurveyFormF7, SurveyFormF8, SurveyFormF9, SurveyFormG, SurveyFormH, SurveyFormI, SurveyFormJ, Submit, SurveyFormDV1, SurveyFormDV2, SurveyFormDV3, SurveyFormDV4, SurveyFormDV5, SurveyFormReflect


urlpatterns = patterns('',
   # url(r'^$', hello),

    url(r'^admin/', include(admin.site.urls)),      
    url(r'^survey/$', survey_views.survey), 
      
    url(r'^begin/$', survey_views.begin),      
    url(r'^start/$', survey_views.start),
    url(r'^surveyfull/$', survey_views.surveyfull),
    
    url(r'^surveyone/$', SurveyWizardOne.as_view([
                                                #Begin                     This is a static page
                                                SurveyFormIT1,     # 0     This is the instruction_task_one page
                                                SurveyFormIT2,     # 1     This is the instruction_task_two page
                                                Start,             # 2     This is the Start page
                                                SurveyFormA,       # 3     First survey question page
                                                SurveyFormB,       # 4     Second survey question page
                                                SurveyFormC,       # 5     Third survey question page
                                                SurveyFormD,       # 6     Forth survey question page
                                                SurveyFormE,       # 7     Fifth survey question page
                                                SurveyFormRate,    # 8     Rate Page
                                                SurveyFormSpike1,  # 9     This is the first Spike image page 
                                                SurveyFormF1,      # 10     This is the first image rating page
                                                SurveyFormF2,      # 11    This is the second image rating page
                                                SurveyFormF3,      # 12    This is the third image rating page
                                                SurveyFormDV1,     # 13    This is the Data verification page for the first group of 3 images
                                                SurveyFormF4,      # 14    This is the fourth image rating page
                                                SurveyFormF5,      # 15    This is the fifth image rating page
                                                SurveyFormF6,      # 16    This is the sixth image rating page
                                                SurveyFormDV2,     # 17    This is the Data verification page for the second group of 3 images
                                                SurveyFormSpike2,  # 18    This is the second Spike image page
                                                SurveyFormF7,      # 19    This is the seventh image rating page
                                                SurveyFormF8,      # 20    This is the eight image rating page
                                                SurveyFormF9,      # 21    This is the ninth image rating page
                                                SurveyFormDV3,     # 22    This is the Data verification page for the third group of 3 images
                                                SurveyFormDV4,     # 23    DV_positive
                                                SurveyFormDV5,     # 24    DV_negative
                                                SurveyFormReflect, # 25    Reflect Page
                                                SurveyFormG,       # 26    Reflective Survey Question page 1
                                                SurveyFormH,       # 27    Reflective Survey Question page 2
                                                SurveyFormI,       # 28    Reflective Survey Question page 3
                                                SurveyFormJ,       # 29    Reflective Survey Question page 4
                                                Submit             # 30    Final Submit Page
                                                #Return_to_Prolific_Academic           This is a static page
                                                 ])),   


    
    url(r'^surveytwo/$', SurveyWizardTwo.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])),   

    url(r'^surveythree/$', SurveyWizardThree.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])), 

    url(r'^surveyfour/$', SurveyWizardFour.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])),  
                       
    url(r'^surveyfive/$', SurveyWizardFive.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])),  

    url(r'^surveysix/$', SurveyWizardSix.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])),   

    url(r'^surveyseven/$', SurveyWizardSeven.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])), 

    url(r'^surveyeight/$', SurveyWizardEight.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])),

    url(r'^surveynine/$', SurveyWizardNine.as_view([
                                                SurveyFormIT1,
                                                SurveyFormIT2,
                                                Start,
                                                SurveyFormA,
                                                SurveyFormB,
                                                SurveyFormC,
                                                SurveyFormD,
                                                SurveyFormE,
                                                SurveyFormRate,
                                                SurveyFormSpike1, 
                                                SurveyFormF1,
                                                SurveyFormF2,
                                                SurveyFormF3,
                                                SurveyFormDV1,
                                                SurveyFormF4,
                                                SurveyFormF5,
                                                SurveyFormF6,
                                                SurveyFormDV2,
                                                SurveyFormSpike2,
                                                SurveyFormF7,
                                                SurveyFormF8,
                                                SurveyFormF9,
                                                SurveyFormDV3,
                                                SurveyFormDV4,
                                                SurveyFormDV5,
                                                SurveyFormReflect,
                                                SurveyFormG,
                                                SurveyFormH,
                                                SurveyFormI,
                                                SurveyFormJ,
                                                Submit             
                                                 ])), 


    #url(r'^contact/$', ContactWizard.as_view([ContactForm1, ContactForm2])),   
    url(r'^(?P<url>About/)$', 'django.contrib.flatpages.views.flatpage'),
    url(r'^(?P<url>Participant_Consent_Form/)$', 'django.contrib.flatpages.views.flatpage'),
    url(r'^(?P<url>Participant_Information_Sheet/)$', 'django.contrib.flatpages.views.flatpage'),
    url(r'^(?P<url>Dummy_Refusal/)$', 'django.contrib.flatpages.views.flatpage'),
    url(r'^slider_one/$', survey_views.sview),
    url(r'^slider_two/$', survey_views.slideview),
    url(r'^jquerytest/$', survey_views.jquerytest),
    url(r'^slide_test/$', survey_views.slide_test),
)

#)